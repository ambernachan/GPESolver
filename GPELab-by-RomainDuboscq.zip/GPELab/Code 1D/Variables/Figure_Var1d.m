%% Creation of the figure variable
%% OUTPUT:
%%          Figure: Structure containing variables concerning the figures (structure)

function [Figure] = Figure_Var1d
Figure.x = 'x';